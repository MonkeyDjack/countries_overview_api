module FusionchartsExporter
  module ApplicationHelper
  end
end
