class SalesRecord < ApplicationRecord
end
