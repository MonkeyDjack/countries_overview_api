module SamplesHelper
end
